export interface Genero{ 
   nome: string;}