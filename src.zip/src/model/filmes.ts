export interface Filme{
    titulo: string;
    genero:string;}