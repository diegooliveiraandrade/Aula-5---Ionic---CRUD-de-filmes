/*
 *@Author: Danilo Rodrigues Oliveira
 *@RA: 81612248
*/ 

export interface Filme{
    nome: string;
    genero: string;
}